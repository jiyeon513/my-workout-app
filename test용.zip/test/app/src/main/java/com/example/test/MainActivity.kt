package com.example.test

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.test.model.ExerciseLog
import com.example.test.screenui.HomeScreen
import com.example.test.screenui.HistoryScreen
import com.example.test.screenui.SettingsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Surface(modifier = Modifier.fillMaxSize()) {
                MyMultiPageApp()
            }
        }
    }
}

@Composable
fun MyMultiPageApp() {
    var currentPage by remember { mutableStateOf("home") }
    val exerciseLogs = remember { mutableStateListOf<ExerciseLog>() }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentPage == "home",
                    onClick = { currentPage = "home" },
                    label = { Text("기록 생성") },
                    icon = { Text("🏋️") }
                )
                NavigationBarItem(
                    selected = currentPage == "history",
                    onClick = { currentPage = "history" },
                    label = { Text("일기장") },
                    icon = { Text("📔") }
                )
                NavigationBarItem(
                    selected = currentPage == "settings",
                    onClick = { currentPage = "settings" },
                    label = { Text("AI PT쌤") },
                    icon = { Text("🤖") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)) {
            when (currentPage) {
                "home" -> HomeScreen { exerciseLogs.addAll(it) }
                "history" -> HistoryScreen(exerciseLogs)
                "settings" -> SettingsScreen()
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AppPreview() {
    MyMultiPageApp()
}
